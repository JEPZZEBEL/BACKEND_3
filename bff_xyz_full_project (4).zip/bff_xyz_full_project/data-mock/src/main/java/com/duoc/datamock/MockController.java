package com.duoc.datamock;

import com.duoc.common.Customer;
import com.duoc.common.Account;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/mock")
public class MockController {

    private static final List<Customer> customers = List.of(
        new Customer("c1", "Ana Soto", "ana@bank.xyz", "+56 9 1111 1111"),
        new Customer("c2", "Luis Pérez", "luis@bank.xyz", "+56 9 2222 2222")
    );

    private static final List<Account> accounts = List.of(
        new Account("a1", "c1", "CHECKING", 125000.50),
        new Account("a2", "c1", "SAVINGS", 780000.00),
        new Account("a3", "c2", "CHECKING", 25000.00)
    );

    @GetMapping("/customers")
    public List<Customer> allCustomers() {
        return customers;
    }

    @GetMapping("/customers/{id}")
    public Customer customer(@PathVariable String id) {
        return customers.stream().filter(c -> c.getId().equals(id)).findFirst().orElse(null);
    }

    @GetMapping("/accounts")
    public List<Account> allAccounts() {
        return accounts;
    }

    @GetMapping("/accounts/by-customer/{customerId}")
    public List<Account> accountsByCustomer(@PathVariable String customerId) {
        return accounts.stream().filter(a -> a.getCustomerId().equals(customerId)).toList();
    }
}
