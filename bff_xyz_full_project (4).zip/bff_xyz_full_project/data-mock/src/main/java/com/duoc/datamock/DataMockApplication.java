package com.duoc.datamock;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataMockApplication {
    public static void main(String[] args) {
        SpringApplication.run(DataMockApplication.class, args);
    }
}
