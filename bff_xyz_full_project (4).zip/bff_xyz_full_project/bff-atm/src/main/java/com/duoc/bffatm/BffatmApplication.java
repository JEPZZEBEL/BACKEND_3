package com.duoc.bffatm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BffatmApplication {
    public static void main(String[] args) {
        SpringApplication.run(BffatmApplication.class, args);
    }
}
