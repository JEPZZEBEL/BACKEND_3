package com.duoc.bffatm.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClient;
import com.duoc.common.Account;
import java.util.*;

record AtmBalance(String accountId, double balance) { }

@RestController
@RequestMapping("/api/atm")
public class AtmController {
    private final RestClient client = RestClient.create("http://data-mock:8090");

    @GetMapping("/balance/{accountId}")
    public AtmBalance balance(@PathVariable String accountId) {
        Account[] arr = client.get().uri("/mock/accounts").retrieve().body(Account[].class);
        return Arrays.stream(arr)
                .filter(a -> a.getId().equals(accountId))
                .findFirst()
                .map(a -> new AtmBalance(a.getId(), a.getBalance()))
                .orElse(new AtmBalance(accountId, 0));
    }
}
