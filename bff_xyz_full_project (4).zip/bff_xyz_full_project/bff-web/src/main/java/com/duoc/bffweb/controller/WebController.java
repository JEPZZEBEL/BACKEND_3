package com.duoc.bffweb.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClient;
import com.duoc.common.Customer;
import com.duoc.common.Account;
import java.util.*;

@RestController
@RequestMapping("/api/web")
public class WebController {
    private final RestClient client = RestClient.create("http://data-mock:8090");

    @GetMapping("/customers")
    public List<Customer> customers() {
        Customer[] arr = client.get().uri("/mock/customers").retrieve().body(Customer[].class);
        return Arrays.asList(arr);
    }

    @GetMapping("/customers/{id}/accounts")
    public List<Account> accounts(@PathVariable String id) {
        Account[] arr = client.get().uri("/mock/accounts/by-customer/{id}", id).retrieve().body(Account[].class);
        return Arrays.asList(arr);
    }
}
