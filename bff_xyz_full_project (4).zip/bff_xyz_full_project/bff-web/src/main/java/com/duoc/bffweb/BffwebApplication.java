package com.duoc.bffweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BffwebApplication {
    public static void main(String[] args) {
        SpringApplication.run(BffwebApplication.class, args);
    }
}
