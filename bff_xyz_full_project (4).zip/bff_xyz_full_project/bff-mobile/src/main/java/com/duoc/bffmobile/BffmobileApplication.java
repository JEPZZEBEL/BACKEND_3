package com.duoc.bffmobile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BffmobileApplication {
    public static void main(String[] args) {
        SpringApplication.run(BffmobileApplication.class, args);
    }
}
