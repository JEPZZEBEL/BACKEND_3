package com.duoc.bffmobile.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClient;
import com.duoc.common.Customer;
import com.duoc.common.Account;
import java.util.*;   // este sí se usa

record MobileCustomer(String id, String name) { }
record MobileAccount(String id, double balance) { }

@RestController
@RequestMapping("/api/mobile")
public class MobileController {
    private final RestClient client = RestClient.create("http://data-mock:8090");

    @GetMapping("/customers")
    public List<MobileCustomer> customers() {
        Customer[] arr = client.get().uri("/mock/customers").retrieve().body(Customer[].class);
        return Arrays.stream(arr).map(c -> new MobileCustomer(c.getId(), c.getName())).toList();
    }

    @GetMapping("/customers/{id}/accounts")
    public List<MobileAccount> accounts(@PathVariable String id) {
        Account[] arr = client.get().uri("/mock/accounts/by-customer/{id}", id).retrieve().body(Account[].class);
        return Arrays.stream(arr).map(a -> new MobileAccount(a.getId(), a.getBalance())).toList();
    }
}
